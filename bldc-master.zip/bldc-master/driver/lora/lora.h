/*
    */

#ifndef HWCONF_RFM95W_H_
#define HWCONF_RFM95W_H_

#include "datatypes.h"
#include "SX1278.h"
#include "SX1278_hw.h"

// Functions
void lora_init(void);
void lora_stop(void);

#endif /* HWCONF_DRV8301_H_ */
